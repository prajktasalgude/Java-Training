package com.java.controller;
import java.util.List;

import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.java.entities.Institute;
import com.java.service.InstituteService;
import com.java.service.InstituteServiceImplementation;
import com.java.entities.Students;
import com.java.service.StudentService;
import com.java.service.StudentServiceImplementation;

@Path("/institute") 
public class InstituteController {
	InstituteService instituteService = new InstituteServiceImplementation();
		
	@GET				
	@Path("/greet") 
	public String welcome() {
		return "<h1> Welcome to Web Based Controller </h1>";
	}
	
	@GET  @Produces(MediaType.APPLICATION_JSON)
	public List<Institute> getAllCurrencies() {
		System.out.println("CONTROLLER : getAllInstitutes()....");
		return instituteService.findInstitutesService();	
	}
	
	@GET @Path("/{cid}") @Produces(MediaType.APPLICATION_JSON)
	public Response getCurrency(@PathParam("cid") String instituteCode) {
		System.out.println("CONTROLLER : getInstitute(String)...."+instituteCode);
		try {
			Institute currObj = instituteService.findInstituteService(instituteCode);
			
			return Response
		      .status(Response.Status.OK)
		      .entity(currObj)
		      .build();
		} catch (com.java.exceptions.CurrencyNotFoundException e) {
			return Response
		      .status(Response.Status.NOT_FOUND)
		      .entity(e.getMessage())
		      .build();
		}
	
	}
	
	StudentService studentService = new StudentServiceImplementation();
	
	@GET  @Path("/students/{cid}")@Produces(MediaType.APPLICATION_JSON)
	public List<Students> getAllStudentsFromInstitute(@PathParam("cid") String instCode) {
		System.out.println("CONTROLLER : getInstitute(String)...."+instCode);
//		try {
			Institute instObj = instituteService.findInstituteService(instCode);
			System.out.println("CONTROLLER : getAllStudentsFrom Institute(String)....");
			 return studentService.findStudentsService(instObj);
			
//			return Response
//		      .status(Response.Status.OK)
//		      .entity(currObj)
//		      .build();
//		} catch (com.java.exceptions.CurrencyNotFoundException e) {
//			return Response
//		      .status(Response.Status.NOT_FOUND)
//		      .entity(e.getMessage())
//		      .build();
//		}
			
	}
	
	@POST 
	@Path("/add") 
	public Response  addCurrency(Institute instObj) {	
		try {	
			instituteService.createInstituteService(instObj);
			
			return Response
		      .status(Response.Status.OK)
		      .entity("Institute Added")
		      .build();
			//return "currency added successfully";
		} catch (Exception e) {
			return Response
		      .status(Response.Status.NOT_FOUND)
		      .entity(e.getMessage())
		      .build();
			//return "currency already present";
		}
	}
	
	@PUT
	@Path("/update") 
	public Response  updateCurrency(Institute currObj) {	
		try {
			instituteService.modifyInstituteService(currObj);
			
			return Response
		      .status(Response.Status.OK)
		      .entity("Institute verified")
		      .build();
		} catch (com.java.exceptions.CurrencyNotFoundException e) {
			return Response
		      .status(Response.Status.NOT_FOUND)
		      .entity(e.getMessage())
		      .build();
		}
	}
	
//	@DELETE
//	@Path("/delete/{cid}") 
//	public Response  deleteCurrency(@PathParam("cid") int id) {	
//		try {
//			instituteService.removeCurrencyService(id);
//			
//			return Response
//		      .status(Response.Status.OK)
//		      .entity("Currency Deleted")
//		      .build();
//		} catch (com.java.exceptions.CurrencyNotFoundException e) {
//			return Response
//		      .status(Response.Status.NOT_FOUND)
//		      .entity(e.getMessage())
//		      .build();
//		}
//	}
	
	
//	@GET
//	@Path("/convert/{src}/{trg}/{amt}")
//	public double convertIt(@PathParam("src") String source, @PathParam("trg") String target, @PathParam("amt")  float amountToConvert) {
//		double amt=0;
//		try {
//			amt = instituteService.calculateCurrencyService(source, target, amountToConvert);
//		} 
//		catch (Exception e) {e.printStackTrace();} 
//		return amt;
//	}
	
}
