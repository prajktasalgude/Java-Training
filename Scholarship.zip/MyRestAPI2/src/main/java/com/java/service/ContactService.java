package com.java.service;

import java.util.List;

import com.java.entities.Contact;

public interface ContactService {
	void createContactService(Contact contact);
	Contact findContactService(String aadharNumber);
	List<Contact> findContactsService();
	void modifyContactService(Contact contact);
	void removeAccountService(String aadhartNumber);
}
