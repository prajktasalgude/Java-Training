package com.java.working;

import java.util.List;

import org.junit.Test;

import com.java.entities.Scholarship;
import com.java.entities.Students;
import com.java.service.StudentService;
import com.java.service.StudentServiceImplementation;
import com.java.service.ScholarshipService;
import com.java.service.ScholarshipServiceImplementation;

public class InstituteLogin {

	StudentService studSer=new StudentServiceImplementation();
	ScholarshipService schSer=new ScholarshipServiceImplementation();
	@Test
	public void studentApprovalTest() {
	List <Students> studList=studSer.findStudentsService();		
	for(Students stud:studList) {
		
		Scholarship sch=schSer.findScholarshipService(stud.getAadharNumber());
		if(sch!=null && sch.getNTSE().equals("Applied") ) {
			
			sch.setNTSE("Approved");
			schSer.modifyScholarshipService(sch);
			System.out.println(sch);
		}
		if(sch!=null && sch.getPMS().equals("Applied") ) {
			
			sch.setPMS("Approved");
			schSer.modifyScholarshipService(sch);
			System.out.println(sch);
		}
		if(sch!=null && sch.getPragati().equals("Applied") ) {
			
			sch.setPragati("Approved");
			schSer.modifyScholarshipService(sch);
			System.out.println(sch);
		}
	}
}
}
