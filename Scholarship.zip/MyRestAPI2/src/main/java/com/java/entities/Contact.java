package com.java.entities;

public class Contact {
	
	private String aadharNumber;
	private String instituteCode;
	private String state;
	private String district;
	private String addressLine;
	private String pincode;
	private String mobileNumber;
	private String email;
	
	public String getAadharNumber() {
		return aadharNumber;
	}
	public void setAadharNumber(String aadharNumber) {
		this.aadharNumber = aadharNumber;
	}
	public String getInstituteCode() {
		return instituteCode;
	}
	public void setInstituteCode(String instituteCode) {
		this.instituteCode = instituteCode;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getDistrict() {
		return district;
	}
	public void setDistrict(String district) {
		this.district = district;
	}
	public String getAddressLine() {
		return addressLine;
	}
	public void setAddressLine(String addressLine) {
		this.addressLine = addressLine;
	}
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	@Override
	public String toString() {
		return "Contact [aadharNumber=" + aadharNumber + ", instituteCode=" + instituteCode + ", state=" + state
				+ ", district=" + district + ", addressLine=" + addressLine + ", pincode=" + pincode + ", mobileNumber="
				+ mobileNumber + ", email=" + email + "]";
	}
	
	
}
