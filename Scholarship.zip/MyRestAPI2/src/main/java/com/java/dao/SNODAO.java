package com.java.dao;

import java.util.List;

import com.java.entities.SNO;

public interface SNODAO {
	public void insertSNO(SNO sno);
	public SNO selectSNO(String username);
	public List<SNO> selectSNOs();
	public void updateSNO(SNO sno);
}